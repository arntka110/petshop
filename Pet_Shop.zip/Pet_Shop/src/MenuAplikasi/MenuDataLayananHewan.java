package MenuAplikasi;

import Database.KoneksiSQL;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MenuDataLayananHewan extends javax.swing.JFrame {

    public MenuDataLayananHewan() {
        initComponents();
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
        
        tampilkandata();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtharga = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtcari = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnbatal = new javax.swing.JButton();
        btnubah = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbllayanan = new javax.swing.JTable();
        txtdeskripsi = new javax.swing.JTextField();
        btnsimpan = new javax.swing.JButton();
        btncari = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btnkembali = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        btnkeluar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 191, 217));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(161, 106, 74));
        jLabel3.setText("COCO");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 100, 80, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("DATA LAYANAN HEWAN PELIHARAAN");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 370, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-pets-96.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 100, 100));

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("PETSHOP");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, -1, 40));
        jPanel1.add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 170, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nama Layanan");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, 30));
        jPanel1.add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 170, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Id Layanan");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, 30));
        jPanel1.add(txtcari, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 170, 30));
        jPanel1.add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 170, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Cari");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 40, 30));

        btnbatal.setBackground(new java.awt.Color(255, 102, 102));
        btnbatal.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnbatal.setForeground(new java.awt.Color(255, 255, 255));
        btnbatal.setText("Batal");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });
        jPanel1.add(btnbatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, 80, 30));

        btnubah.setBackground(new java.awt.Color(120, 129, 153));
        btnubah.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnubah.setForeground(new java.awt.Color(255, 255, 255));
        btnubah.setText("Ubah");
        btnubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnubahActionPerformed(evt);
            }
        });
        jPanel1.add(btnubah, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 80, 30));

        jPanel2.setBackground(new java.awt.Color(0, 153, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("List Data Layanan Hewan Peliharaan");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(454, 244, 300, 30));

        tbllayanan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Id Layanan", "Nama Layanan", "Harga", "Deskripsi"
            }
        ));
        tbllayanan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbllayananMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbllayanan);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 270, 310, 150));
        jPanel1.add(txtdeskripsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 330, 170, 30));

        btnsimpan.setBackground(new java.awt.Color(120, 129, 153));
        btnsimpan.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnsimpan.setForeground(new java.awt.Color(255, 255, 255));
        btnsimpan.setText("Simpan");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });
        jPanel1.add(btnsimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 80, 30));

        btncari.setBackground(new java.awt.Color(101, 191, 217));
        btncari.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btncari.setForeground(new java.awt.Color(255, 255, 255));
        btncari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-search-24.png"))); // NOI18N
        btncari.setBorderPainted(false);
        btncari.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });
        jPanel1.add(btncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 200, 80, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Harga Layanan");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, -1, 30));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Kembali");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 50, 30));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Keluar");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 450, 40, 30));

        btnkembali.setBackground(new java.awt.Color(101, 191, 217));
        btnkembali.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkembali.setForeground(new java.awt.Color(101, 191, 217));
        btnkembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-go-back-30.png"))); // NOI18N
        btnkembali.setBorder(null);
        btnkembali.setBorderPainted(false);
        btnkembali.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkembaliActionPerformed(evt);
            }
        });
        jPanel1.add(btnkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, -1));

        btnhapus.setBackground(new java.awt.Color(255, 102, 102));
        btnhapus.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnhapus.setForeground(new java.awt.Color(255, 255, 255));
        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });
        jPanel1.add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 80, 30));

        btnkeluar.setBackground(new java.awt.Color(101, 191, 217));
        btnkeluar.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkeluar.setForeground(new java.awt.Color(101, 191, 217));
        btnkeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-logout-rounded-32.png"))); // NOI18N
        btnkeluar.setBorder(null);
        btnkeluar.setBorderPainted(false);
        btnkeluar.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });
        jPanel1.add(btnkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 450, 80, 30));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 90, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 50, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Deskripsi");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 788, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
        carilayanan();
    }//GEN-LAST:event_btncariActionPerformed

    private void btnkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkembaliActionPerformed
        this.dispose();
        
        //object
        MenuAdmin kembali = new MenuAdmin();
        kembali.setVisible(true);
    }//GEN-LAST:event_btnkembaliActionPerformed

    private void btnubahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnubahActionPerformed
        ubahlayanan();
        clrform();
    }//GEN-LAST:event_btnubahActionPerformed

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        tambahlayanan();
        clrform();
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        hapuslayanan();
        clrform();
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
        clrform();
    }//GEN-LAST:event_btnbatalActionPerformed

    private void tbllayananMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbllayananMouseClicked
        // buat input data yang ada ditabel secara otomatis
        int baris = tbllayanan.rowAtPoint(evt.getPoint());
        String idlayanan = tbllayanan.getValueAt(baris, 1).toString();
        txtid.setText(idlayanan);
        String namalayanan = tbllayanan.getValueAt(baris, 2).toString();
        txtnama.setText(namalayanan);
        String harga = tbllayanan.getValueAt(baris, 3).toString();
        txtharga.setText(harga);
        String deskripsi = tbllayanan.getValueAt(baris, 4).toString();
        txtdeskripsi.setText(deskripsi);
    }//GEN-LAST:event_tbllayananMouseClicked

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        this.dispose();
        JOptionPane.showMessageDialog(null, "Logout...");
        Login login = new Login();
        login.setVisible(true);
    }//GEN-LAST:event_btnkeluarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuDataLayananHewan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuDataLayananHewan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuDataLayananHewan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuDataLayananHewan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuDataLayananHewan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btncari;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkembali;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton btnubah;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbllayanan;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtdeskripsi;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtnama;
    // End of variables declaration//GEN-END:variables

    public void clrform() {
        txtid.setText("");
        txtnama.setText("");
        txtharga.setText("");
        txtdeskripsi.setText("");
    }
    
    //CREATE
    public void tambahlayanan() {
        try{
           String sql = "INSERT INTO tbl_layanan VALUES('"
                   +txtid.getText()+"','"
                   +txtnama.getText()+"','"
                   +txtharga.getText()+"','"
                   +txtdeskripsi.getText()+"');";
           java.sql.Connection con = (Connection) KoneksiSQL.connect();
           java.sql.Statement stm = con.createStatement();
           java.sql.PreparedStatement pstm = con.prepareStatement(sql);
           pstm.execute();
           JOptionPane.showMessageDialog(null, "Layanan telah ditambahkan!");
           tampilkandata();
           clrform();
       }
       catch (SQLException e){
           JOptionPane.showMessageDialog(this, "Tambah layanan gagal!");
           JOptionPane.showMessageDialog(this, e.getMessage());
       }
    }
    
    //READ
    public void tampilkandata(){
        // bikin tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Id");
        model.addColumn("Nama Layanan");
        model.addColumn("Harga");
        model.addColumn("Deskripsi");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM tbl_layanan";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1),
                    rst.getString(2), rst.getString(3), rst.getString(4)});
            }
            tbllayanan.setModel(model);
            clrform();
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }

    //UPDATE
    public void ubahlayanan(){
        try{
            String sql = "UPDATE tbl_layanan SET id_layanan='"+txtid.getText()
                    +"', nama_layanan='" + txtnama.getText()
                    +"', harga_layanan='" + txtharga.getText()
                    +"', deskripsi='" + txtdeskripsi.getText()
                    + "' WHERE id_layanan = '" + txtid.getText()+"'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data layanan telah diubah!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Data layanan gagal diubah!");
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clrform();            
    }
    
    //DELETE
    public void hapuslayanan(){
        try{
            String sql = "DELETE FROM tbl_layanan WHERE id_layanan='"+txtid.getText()+"'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data layanan telah dihapus!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Data layanan gagal dihapus!");
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clrform();              
    }
    
    //SEARCH
    public void carilayanan(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Id");
        model.addColumn("Nama Layanan");
        model.addColumn("Harga");
        model.addColumn("Deskripsi");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM tbl_layanan WHERE id_layanan like '%"+txtcari.getText()
                    +"%'or nama_layanan like '%"+txtcari.getText()+"%'"
                    + "or harga_layanan like '%"+txtcari.getText()+"%'";
                    
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql); //untuk menampilkan/memilih data dari database
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4)});
            }
            tbllayanan.setModel(model);
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }
}