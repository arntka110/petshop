package MenuAplikasi;

import Database.KoneksiSQL;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class MenuDataBarang extends javax.swing.JFrame {

    public MenuDataBarang() {
        initComponents();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2, //menentukan lebar
        (screenSize.height - frameSize.height) / 2); //menentukan panjang
        
        tampilkandata();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtjenis = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtstok = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtcari = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnbatal = new javax.swing.JButton();
        btnubah = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblbarang = new javax.swing.JTable();
        txttanggal = new javax.swing.JTextField();
        btnsimpan = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        btnhapus = new javax.swing.JButton();
        txtharga = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btncari = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        btnkeluar = new javax.swing.JButton();
        btnkembali = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 191, 217));
        jPanel1.setPreferredSize(new java.awt.Dimension(710, 480));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-pets-96.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 100, 100));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(161, 106, 74));
        jLabel3.setText("COCO");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, 80, 40));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 110, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("DATA BARANG");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 150, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("PETSHOP");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 100, -1, 40));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Stok Barang");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 330, -1, 30));
        jPanel1.add(txtjenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 170, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nama Barang");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, -1, 30));
        jPanel1.add(txtstok, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 360, 170, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Harga Jual");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 260, -1, 30));
        jPanel1.add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 170, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Id Barang");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, 30));
        jPanel1.add(txtcari, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, 170, 30));
        jPanel1.add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 170, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Tanggal Kadaluarsa");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 190, -1, 30));

        btnbatal.setBackground(new java.awt.Color(255, 102, 102));
        btnbatal.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnbatal.setForeground(new java.awt.Color(255, 255, 255));
        btnbatal.setText("Batal");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });
        jPanel1.add(btnbatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 410, 80, 30));

        btnubah.setBackground(new java.awt.Color(120, 129, 153));
        btnubah.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnubah.setForeground(new java.awt.Color(255, 255, 255));
        btnubah.setText("Ubah");
        btnubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnubahActionPerformed(evt);
            }
        });
        jPanel1.add(btnubah, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 410, 80, 30));

        jPanel2.setBackground(new java.awt.Color(0, 153, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("List Data Hewan Peliharaan");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(454, 224, 300, 30));

        tblbarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "No", "Id", "Nama", "Jenis", "Expired", "Harga", "Stok"
            }
        ));
        tblbarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblbarangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblbarang);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 250, 310, 190));
        jPanel1.add(txttanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 220, 170, 30));

        btnsimpan.setBackground(new java.awt.Color(120, 129, 153));
        btnsimpan.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnsimpan.setForeground(new java.awt.Color(255, 255, 255));
        btnsimpan.setText("Simpan");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });
        jPanel1.add(btnsimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 80, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Jenis Barang");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, 30));

        btnhapus.setBackground(new java.awt.Color(255, 102, 102));
        btnhapus.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnhapus.setForeground(new java.awt.Color(255, 255, 255));
        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });
        jPanel1.add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 410, 80, 30));
        jPanel1.add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 170, 30));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Keluar");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 450, 40, 20));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Cari");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 180, 40, 30));

        btncari.setBackground(new java.awt.Color(101, 191, 217));
        btncari.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btncari.setForeground(new java.awt.Color(255, 255, 255));
        btncari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-search-24.png"))); // NOI18N
        btncari.setBorderPainted(false);
        btncari.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });
        jPanel1.add(btncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 180, 80, 30));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Kembali");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 50, 20));

        btnkeluar.setBackground(new java.awt.Color(101, 191, 217));
        btnkeluar.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkeluar.setForeground(new java.awt.Color(101, 191, 217));
        btnkeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-logout-rounded-32.png"))); // NOI18N
        btnkeluar.setBorder(null);
        btnkeluar.setBorderPainted(false);
        btnkeluar.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });
        jPanel1.add(btnkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 440, 80, 40));

        btnkembali.setBackground(new java.awt.Color(101, 191, 217));
        btnkembali.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkembali.setForeground(new java.awt.Color(101, 191, 217));
        btnkembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-go-back-30.png"))); // NOI18N
        btnkembali.setBorder(null);
        btnkembali.setBorderPainted(false);
        btnkembali.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkembaliActionPerformed(evt);
            }
        });
        jPanel1.add(btnkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 792, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkembaliActionPerformed
        this.dispose();

        //object
        MenuAdmin kembali = new MenuAdmin();
        kembali.setVisible(true);
    }//GEN-LAST:event_btnkembaliActionPerformed

    private void btnubahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnubahActionPerformed
        ubahbarang();
        clrform();
    }//GEN-LAST:event_btnubahActionPerformed

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
        caribarang();
    }//GEN-LAST:event_btncariActionPerformed

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        tambahbarang();
        clrform();
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        hapusbarang();
        clrform();
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
        clrform();
    }//GEN-LAST:event_btnbatalActionPerformed

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        this.dispose();
        JOptionPane.showMessageDialog(null, "Logout...");
        Login login = new Login();
        login.setVisible(true);
    }//GEN-LAST:event_btnkeluarActionPerformed

    private void tblbarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblbarangMouseClicked
        // buat input data yang ada ditabel secara otomatis
        int baris = tblbarang.rowAtPoint(evt.getPoint());
        String idbarang = tblbarang.getValueAt(baris, 1).toString();
        txtid.setText(idbarang);
        String namabarang = tblbarang.getValueAt(baris, 2).toString();
        txtnama.setText(namabarang);
        String jenisbarang = tblbarang.getValueAt(baris, 3).toString();
        txtjenis.setText(jenisbarang);
        String expired = tblbarang.getValueAt(baris, 4).toString();
        txttanggal.setText(expired);
        String harga = tblbarang.getValueAt(baris, 5).toString();
        txtharga.setText(harga);
        String stok = tblbarang.getValueAt(baris, 6).toString();
        txtstok.setText(stok);
    }//GEN-LAST:event_tblbarangMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuDataBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuDataBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuDataBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuDataBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuDataBarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btncari;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkembali;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton btnubah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblbarang;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtjenis;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtstok;
    private javax.swing.JTextField txttanggal;
    // End of variables declaration//GEN-END:variables

    public void clrform() {
        txtid.setText("");
        txtnama.setText("");
        txtjenis.setText("");
        txttanggal.setText("");
        txtharga.setText("");
        txtstok.setText("");
    }
    
    //CREATE
    public void tambahbarang() {
        try{
           String sql = "INSERT INTO tbl_barang VALUES('"
                   +txtid.getText()+"','"
                   +txtnama.getText()+"','"
                   +txtjenis.getText()+"','"
                   +txttanggal.getText()+"','"
                   +txtharga.getText()+"','"
                   +txtstok.getText()+"');";
           java.sql.Connection con = (Connection) KoneksiSQL.connect();
           java.sql.Statement stm = con.createStatement();
           java.sql.PreparedStatement pstm = con.prepareStatement(sql);
           pstm.execute();
           JOptionPane.showMessageDialog(null, "Data barang telah ditambahkan!");
           tampilkandata();
           clrform();
       }
       catch (SQLException e){
           JOptionPane.showMessageDialog(this, "Tambah data barang gagal!");
           JOptionPane.showMessageDialog(this, e.getMessage());
       }
    }
    
    //READ
    public void tampilkandata(){
        // bikin tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Id");
        model.addColumn("Nama Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Expired");
        model.addColumn("Harga");
        model.addColumn("Stok");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM tbl_barang";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6)});
            }
            tblbarang.setModel(model);
            clrform();
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }
    
    //UPDATE
    public void ubahbarang(){
        try{
            String sql = "UPDATE tbl_barang SET id_barang='"+txtid.getText()
                    +"', nama_barang='" + txtnama.getText()
                    +"', jenis_barang='" + txtjenis.getText()
                    +"', tgl_kadaluarsa='" + txttanggal.getText()
                    +"', harga_jual='" + txtharga.getText()
                    +"', stok_barang='" + txtstok.getText()
                    + "' WHERE id_barang = '" + txtid.getText()+"'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data barang telah diubah!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Data barang gagal diubah!");
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clrform();            
    }
    
    //DELETE
    public void hapusbarang(){
        try{
            String sql = "DELETE FROM tbl_barang WHERE id_barang='"+txtid.getText()+"'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data barang telah dihapus!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, "Data barang gagal dihapus!");
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clrform();              
    }

    //SEARCH
    public void caribarang(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Id");
        model.addColumn("Nama Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Expired");
        model.addColumn("Harga");
        model.addColumn("Stok");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM tbl_barang WHERE id_barang like '%"+txtcari.getText()
                    +"%'or nama_barang like '%"+txtcari.getText()+"%'"
                    +"or jenis_barang like '%"+txtcari.getText()+"%'"
                    +"or tgl_kadaluarsa like '%"+txtcari.getText()+"%'"
                    +"or harga_jual like '%"+txtcari.getText()+"%'";
                    
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql); //untuk menampilkan/memilih data dari database
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6)});
            }
            tblbarang.setModel(model);
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }
}
