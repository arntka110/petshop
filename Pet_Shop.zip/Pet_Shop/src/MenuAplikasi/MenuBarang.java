package MenuAplikasi;

import Database.KoneksiSQL;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MenuBarang extends javax.swing.JFrame {

    
    public MenuBarang() {
        initComponents();
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2, //menentukan lebar
        (screenSize.height - frameSize.height) / 2); //menentukan panjang
        
        tampilkandata();
        autoidtransaksi();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        btnkembali = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        spnjumlah = new javax.swing.JSpinner();
        txtidtransaksi = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtjenis = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblbarang = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        txtharga = new javax.swing.JTextField();
        btnbatal = new javax.swing.JButton();
        btnproses = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        txtidbarang = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        btnkeluar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtbayar = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtkembalian = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txttotal = new javax.swing.JTextField();
        btnbayar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setPreferredSize(new java.awt.Dimension(755, 650));

        jPanel1.setBackground(new java.awt.Color(101, 191, 217));
        jPanel1.setMinimumSize(new java.awt.Dimension(770, 650));
        jPanel1.setPreferredSize(new java.awt.Dimension(755, 650));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 30, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-pets-96.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 100, 100));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(161, 106, 74));
        jLabel3.setText("COCO");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 80, 40));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30 (1).png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("PETSHOP");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 90, -1, 40));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-cat-footprint-30.png"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, -1, -1));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Kembali");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 50, 30));

        btnkembali.setBackground(new java.awt.Color(101, 191, 217));
        btnkembali.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkembali.setForeground(new java.awt.Color(101, 191, 217));
        btnkembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-go-back-30.png"))); // NOI18N
        btnkembali.setBorder(null);
        btnkembali.setBorderPainted(false);
        btnkembali.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkembaliActionPerformed(evt);
            }
        });
        jPanel1.add(btnkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("BARANG DAN PERLENGKAPAN HEWAN PELIHARAAN");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 450, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Silahkan pilih perlengkapan untuk hewan kesayangan Anda.");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 350, 30));

        jPanel3.setBackground(new java.awt.Color(161, 106, 74));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Perlengkapan COCO PetShop", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 15), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Harga");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 40, 20));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Jenis Barang");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, 20));
        jPanel3.add(spnjumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 80, -1));
        jPanel3.add(txtidtransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 130, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Jumlah Barang");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, 20));
        jPanel3.add(txtjenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 130, -1));

        jPanel2.setBackground(new java.awt.Color(93, 64, 55));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("List Perlengkapan Hewan Peliharaan");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, -1, 30));

        jPanel3.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, 345, 30));

        tblbarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "No", "Id", "Nama Barang", "Jenis Barang", "Harga"
            }
        ));
        tblbarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblbarangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblbarang);
        if (tblbarang.getColumnModel().getColumnCount() > 0) {
            tblbarang.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 350, 160));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Id Barang");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, 20));
        jPanel3.add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 130, -1));

        btnbatal.setBackground(new java.awt.Color(255, 102, 102));
        btnbatal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnbatal.setForeground(new java.awt.Color(255, 255, 255));
        btnbatal.setText("Batal");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });
        jPanel3.add(btnbatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 263, 90, 30));

        btnproses.setBackground(new java.awt.Color(93, 64, 55));
        btnproses.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnproses.setForeground(new java.awt.Color(255, 255, 255));
        btnproses.setText("Proses");
        btnproses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprosesActionPerformed(evt);
            }
        });
        jPanel3.add(btnproses, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 263, 90, 30));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-pet-food-64.png"))); // NOI18N
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, 70, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-pet-toys-64.png"))); // NOI18N
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 250, -1, 70));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Nama Barang");
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, 20));
        jPanel3.add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 130, -1));
        jPanel3.add(txtidbarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 130, -1));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Id Transaksi");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, 680, 320));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Keluar");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 620, 40, 30));

        btnkeluar.setBackground(new java.awt.Color(101, 191, 217));
        btnkeluar.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnkeluar.setForeground(new java.awt.Color(101, 191, 217));
        btnkeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Foto/icons8-logout-rounded-32.png"))); // NOI18N
        btnkeluar.setBorder(null);
        btnkeluar.setBorderPainted(false);
        btnkeluar.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });
        jPanel1.add(btnkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 620, 80, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Nominal Pembayaran");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 550, 150, 30));
        jPanel1.add(txtbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 550, 200, 30));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Kembalian");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 590, -1, 30));
        jPanel1.add(txtkembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 590, 160, 30));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Total Pembayaran");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, -1, 30));
        jPanel1.add(txttotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 550, 160, 30));

        btnbayar.setBackground(new java.awt.Color(93, 64, 55));
        btnbayar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnbayar.setForeground(new java.awt.Color(255, 255, 255));
        btnbayar.setText("Bayar");
        btnbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbayarActionPerformed(evt);
            }
        });
        jPanel1.add(btnbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 590, 90, 30));

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 765, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkembaliActionPerformed
        this.dispose();

        //object
        MenuAdmin kembali = new MenuAdmin();
        kembali.setVisible(true);
    }//GEN-LAST:event_btnkembaliActionPerformed

    private void btnbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbayarActionPerformed
        bayar();
    }//GEN-LAST:event_btnbayarActionPerformed

    private void btnprosesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprosesActionPerformed
        autoidtransaksi();
        totalbayar();
    }//GEN-LAST:event_btnprosesActionPerformed

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
        clrform();
        autoidtransaksi();
    }//GEN-LAST:event_btnbatalActionPerformed

    private void tblbarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblbarangMouseClicked
        // buat input data yang ada ditabel secara otomatis
        int baris = tblbarang.rowAtPoint(evt.getPoint());
        String idbarang = tblbarang.getValueAt(baris, 1).toString();
        txtidbarang.setText(idbarang);
        String namabarang = tblbarang.getValueAt(baris, 2).toString();
        txtnama.setText(namabarang);
        String jenisbarang = tblbarang.getValueAt(baris, 3).toString();
        txtjenis.setText(jenisbarang);
        String harga = tblbarang.getValueAt(baris, 5).toString();
        txtharga.setText(harga);
    }//GEN-LAST:event_tblbarangMouseClicked

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        this.dispose();
        JOptionPane.showMessageDialog(null, "Logout...");
        Login login = new Login();
        login.setVisible(true);
    }//GEN-LAST:event_btnkeluarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuBarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btnbayar;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkembali;
    private javax.swing.JButton btnproses;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner spnjumlah;
    private javax.swing.JTable tblbarang;
    private javax.swing.JTextField txtbayar;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtidbarang;
    private javax.swing.JTextField txtidtransaksi;
    private javax.swing.JTextField txtjenis;
    private javax.swing.JTextField txtkembalian;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txttotal;
    // End of variables declaration//GEN-END:variables

    public void clrform(){
        txtidtransaksi.setText("");
        txtidbarang.setText("");
        txtnama.setText("");
        txtjenis.setText("");
        spnjumlah.setValue(0);
        txtharga.setText("");
        txttotal.setText("0");
        txtkembalian.setText("0");
        txtbayar.setText("0");
    }
    
    public void tampilkandata(){
        // bikin tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Id");
        model.addColumn("Nama Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Expired");
        model.addColumn("Harga");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM tbl_barang";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1),
                    rst.getString(2), rst.getString(3), rst.getString(4),
                    rst.getString(5)});
            }
            tblbarang.setModel(model);
            clrform();
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }

    private void autoidtransaksi(){
        try {
            String sql = "SELECT*FROM tbl_riwayat_transaksi ORDER BY id_transaksi DESC";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            if (rst.next()) {
                String idtransaksi = rst.getString("id_transaksi").substring(2);
                String TR = "" + (Integer.parseInt(idtransaksi)+1);
                String no1 = "";
                
                if(TR.length()==1)
                {no1 = "000";}
                else if (TR.length()==2)
                {no1 = "00";}
                else if (TR.length()==3)
                {no1 = "0";}
                else if (TR.length()==4)
                {no1 = "";}
                txtidtransaksi.setText("TR" + no1 + TR);
            }
            else {
                txtidtransaksi.setText("TR1101");
            }
        }
        catch (Exception e) {
            System.out.println("");
        }
    }
    
    public void tambahdatatransaksi(){
        try{
            int baris = tblbarang.getRowCount();
            for (int i = 0; i < baris; i++) {
                String sql = "INSERT INTO tbl_riwayat_transaksi (id_transaksi, total_pembayaran, id_barang) VALUES('"
                            +txtidtransaksi.getText()+"','"
                            +txttotal.getText()+"','"
                            +txtidbarang.getText()+"')";
                    java.sql.Connection con = (Connection) KoneksiSQL.connect();
                    java.sql.Statement stm = con.createStatement();
                    java.sql.PreparedStatement pstm = con.prepareStatement(sql);
                    pstm.execute();
            }
        }
        
        catch (SQLException e){
            System.out.println("");
       }
    }
    
    public void totalbayar(){
        int total = 0;
        int jumlah, harga;
        jumlah = (int) spnjumlah.getValue();
        harga = Integer.parseInt(txtharga.getText());
        if (jumlah <= 0) {
            JOptionPane.showMessageDialog(null, "Silahkan masukan jumlah barang!");
        }
        else {
            total = total + (jumlah*harga);
            txttotal.setText(String.valueOf(total));
            JOptionPane.showMessageDialog(null, "Sedang memproses pembayaran...");
            JOptionPane.showMessageDialog(null, "Proses berhasil!\nSilahkan lakukan pembayaran!");
        }
    }
    
    public void bayar(){
        int total, bayar, kembalian;
        total = Integer.parseInt(txttotal.getText());
        bayar = Integer.parseInt(txtbayar.getText());
        
        if (bayar < total) {
            JOptionPane.showMessageDialog(null, "Maaf jumlah uang Anda kurang, silahkan masukkan jumlah uang!");
        }
        else if (bayar >= total){
            kembalian = bayar - total;
            txtkembalian.setText(String.valueOf(kembalian));
            JOptionPane.showMessageDialog(null, "Transaksi berhasil!\nSilahkan tunggu informasi lebih lanjut melalui message box!\nTerimkasih!");
            JOptionPane.showMessageDialog(null, "Silahkan screen shoot message ini sebagai bukti pembayaran!\n\nId Transaksi\t: " + txtidtransaksi.getText() + "\nNama Barang\t\t: " + txtnama.getText() + "\nTotal Pembayaran\t: " + txttotal.getText());
            tambahdatatransaksi();
            tampilkandata();
            clrform();
            autoidtransaksi();
        }
    }
}
