package MenuAplikasi;

public class MainMenu extends Login{

    
    public static void main(String[] args) {
        // object buat jalankan class Login
        Login login = new Login();
        login.setVisible(true);
    }
    
}
